function [speakers_GMM_model] = GMM_model_creation(num_of_components)

%extract the training data
[female,male,speaker_frames,size_t_female,size_t_male] = training_data_feature_extraction();

%store the mfcc in each cells into on single matrix
num_of_speakers = length(female.speakers)+length(female.speakers);
    
    size_t = size_t_female+ size_t_male;
    mfccs = zeros(size_t,13);
    counter = 1;
    for i = 1:size(female.speech,1)
     % Loop through files
        for j = 1:size(female.speech,2)
            mfccs(counter:counter+size(female.mfccs{i,j},1)-1,:) = female.mfccs{i,j};
            counter = counter+size(female.mfccs{i,j},1);
        
        end
    end


    for i = 1:size(male.speech,1)
    % Loop through files
        for j = 1:size(male.speech,2)
           mfccs(counter:counter+size(male.mfccs{i,j},1)-1,:) =male.mfccs{i,j};
          counter = counter+size(male.mfccs{i,j},1);
      
        
        end
    end
  


%model creation, creating different GMMs for each speaker
%based on speaker's own speech data
speakers_GMM_model = cell(num_of_speakers,2);

speaker_frames = [speaker_frames];
mfcc_extraction_it = 1;
for speaker_iterator = 1:num_of_speakers 
    enrolement_speakers_mfcc = mfccs(mfcc_extraction_it:mfcc_extraction_it+speaker_frames(speaker_iterator)-1,:);

       [gmm_model] = EM(enrolement_speakers_mfcc,num_of_components);
    if speaker_iterator > 5
       speakers_GMM_model {speaker_iterator,1} = male.speakers{speaker_iterator-5,1};
    else 
        speakers_GMM_model {speaker_iterator,1} = female.speakers{speaker_iterator,1};
    end 
 
    speakers_GMM_model {speaker_iterator,2} = gmm_model;
    mfcc_extraction_it = mfcc_extraction_it+speaker_frames(speaker_iterator);
    
end