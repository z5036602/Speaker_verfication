clear;clc
%model creation
num_of_components = 10;
[speakers_GMM_model,speakers_UBM_model] = GMM_UBM_model_creation(num_of_components);
[GMM_model] = GMM_model_creation(num_of_components);
[speaker,speaker_frames,size_t] = testing_data_feature_extraction();
%%
%predication
[predicted_label,actual_label] = GMM_UBM_predication(speaker,speakers_GMM_model,speakers_UBM_model);
[GMM_predicted_label,GMM_actual_label] = GMM_predication(speaker,GMM_model);

%error caculation for two sytems, and confusion matrix plots
error = err_caculation (actual_label,predicted_label);
disp(['GMM-UBM Err is : ', num2str(error) , '%']);
figure
cm = confusionchart(actual_label,predicted_label);
title('GMM UBM system with map');
error = err_caculation (GMM_actual_label,GMM_predicted_label);
disp(['GMM Err is : ', num2str(error) , '%']);
figure
cm = confusionchart(GMM_actual_label,GMM_predicted_label);
title('GMM system with ml');