%create the GMM_UBM_model given number of components that user want
%input:
%num_of_components --> number of mixture components
%output:
%speakers_GMM_model --> all speakers GMM model
%speakers_UBM_model --> all speakers UMM model
function [speakers_GMM_model,speakers_UBM_model] = GMM_UBM_model_creation(num_of_components)

%%%num of components must be even number,as half for female,half for male
assert(mod(num_of_components,2) ==0,...
    'num of components must be even number,as half for female,half for male');
num_of_components = num_of_components/2;


%extract features
[female,male,speaker_frames,size_t_female,size_t_male] = training_data_feature_extraction();

%size_t --> total number of frames %num_of_speakers -->number of speakers
num_of_speakers = length(female.speakers)+length(female.speakers);
size_t = size_t_female+ size_t_male;


%store the mfcc in each cells into on single matrix
    mfccs = zeros(size_t,13);
    counter = 1;
    for i = 1:size(female.speech,1)
     % Loop through files
        for j = 1:size(female.speech,2)
            mfccs(counter:counter+size(female.mfccs{i,j},1)-1,:) = female.mfccs{i,j};
            counter = counter+size(female.mfccs{i,j},1);
        
        end
    end


    for i = 1:size(male.speech,1)
    % Loop through files
        for j = 1:size(male.speech,2)
           mfccs(counter:counter+size(male.mfccs{i,j},1)-1,:) =male.mfccs{i,j};
          counter = counter+size(male.mfccs{i,j},1);
      
        
        end
    end
  

%GMM and UBM model creation
speakers_UBM_model = cell(num_of_speakers,2);
speakers_GMM_model = cell(num_of_speakers,2);

mfcc_extraction_it = 1;
for speaker_iterator = 1:num_of_speakers 
    
    %split the traning data to enrolment and training(development)
    enrolement_speakers_mfcc = mfccs(mfcc_extraction_it:mfcc_extraction_it+speaker_frames(speaker_iterator)-1,:);

    training_speakers_mfcc = mfccs;
    training_speakers_mfcc(mfcc_extraction_it:mfcc_extraction_it+speaker_frames(speaker_iterator)-1,:) = [];
    
    
    %create the GMM(UBM) for female and male speakers from training data;
    if (speaker_iterator > (num_of_speakers/2))
        
       [gmm_female_model] = EM(training_speakers_mfcc(1:size_t_female,:),num_of_components);

       [gmm_male_model] = EM(training_speakers_mfcc(size_t_female+1:end,:),num_of_components);
       
       %store the speaker label on the first column first 
       speakers_UBM_model {speaker_iterator,1} = male.speakers{speaker_iterator-5,1};
       speakers_GMM_model {speaker_iterator,1} = male.speakers{speaker_iterator-5,1};
    else 
        size_t_female_training = size_t_female-size(enrolement_speakers_mfcc,1);    
       [gmm_female_model] = EM(training_speakers_mfcc(1:size_t_female_training,:),num_of_components);

       [gmm_male_model] = EM(training_speakers_mfcc(size_t_female_training+1:end,:),num_of_components);
       
       %store the speaker label on the first column first 
        speakers_UBM_model {speaker_iterator,1} = female.speakers{speaker_iterator,1};
        speakers_GMM_model {speaker_iterator,1} = female.speakers{speaker_iterator,1};
    end 
   
  
    %combine the female gmm and male gmm to UBM
    combined_UBM_model.u = [gmm_female_model.u;gmm_male_model.u];
    combined_UBM_model.sigma = cat(3,gmm_female_model.sigma,gmm_male_model.sigma);
    %notice weights are normalized
    combined_UBM_model.weights = [gmm_female_model.weights,gmm_male_model.weights]/2;
    combined_UBM_model.num_of_components = num_of_components*2;
    
    
    %adapt the UBM by enrolment data
    [gmm_model] = mapadapt(enrolement_speakers_mfcc,combined_UBM_model);
    
    
    %store the speaker's GMM-UBM model
    speakers_UBM_model {speaker_iterator,2} = combined_UBM_model;
    speakers_GMM_model {speaker_iterator,2} = gmm_model;
    
    
    %iterate the speakers frame counter
    mfcc_extraction_it = mfcc_extraction_it+speaker_frames(speaker_iterator);
end
end
    
