% 3/9/2019 Zhengyue LIU 
function [output,f_0,voiced_frames] = Josh_MFCC_pitch (x,fs,FrameLen,inc,f_low,f_high,bank_number)
f_0 = pitch(x,fs, ...
     'WindowLength',400, ...
     'OverlapLength',(400-160), ...
      'Range',[50 350], ...
      'Method','NCF');
if( max(abs(x))<=1 ), x = x * 2^15; end
% Preemphasis filtering 
Help_judge_voiced  = enframe(x, FrameLen,inc);
energy = sum(Help_judge_voiced.*Help_judge_voiced,2)/400;
threshold = 0.8*mean(energy);
voiced_frames= find(energy>threshold);



Compensated_sig = filter([1, -0.97], 1, x);

%%%Framing and windowing (frames as rows)
Frames_matrix  = enframe(Compensated_sig, FrameLen,inc);
%energy = sum(Frames_matrix.*Frames_matrix,2)/size(Frames_matrix,2);

number_of_frames = size(Frames_matrix,1);


hamming_window = hamming(size(Frames_matrix,2));
hammming_window_matrix = zeros(number_of_frames,FrameLen);
for i= 1:number_of_frames
    hammming_window_matrix(i,:) = hamming_window;
end


Frames_matrix = Frames_matrix .*hammming_window_matrix;
MAG  = abs(FFT_matrix (Frames_matrix));

nfft= size(MAG,2);
FFT_MA = MAG(:,1:(nfft/2+1));
mel_MA = mel_log(FFT_MA,bank_number,fs,f_low,f_high,nfft);


CC = mel_MA';
dctm = @( N, M )( sqrt(2.0/M) * cos( repmat([0:N-1].',1,M).* repmat(pi*([1:M]-0.5)/M,N,1) ) );
DCT = dctm(13,bank_number);
CC =  (DCT * CC)';

output = CC(voiced_frames,:); 
f_0 = f_0(voiced_frames,:); 

end
