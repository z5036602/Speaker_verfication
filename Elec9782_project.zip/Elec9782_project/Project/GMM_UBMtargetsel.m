%this function caculates the lilihood scoring of data under different GMM-UBM models
% then select the model with highest lilihood as the predication
%output 
%label -- > predicated label
%input 
%speakers_GMM_model -->a struct that stores all speakers GMM 
%speakers_UBM_model -->a struct that stores all speakers UBM 
function [label] = GMM_UBMtargetsel(testing_utterances,speakers_GMM_model,speakers_UBM_model)
    scorings = zeros(10,1);
    for speaker_iterator = 1:size(speakers_GMM_model,1)
        scorings(speaker_iterator) = GMM_UBM_scoring(testing_utterances,speakers_GMM_model{speaker_iterator,2},speakers_UBM_model{speaker_iterator,2});

    end
    [~, idx] = max(scorings);
    label = speakers_GMM_model{idx,1};
end