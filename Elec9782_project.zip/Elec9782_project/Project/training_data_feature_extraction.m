function [female,male,speaker_frames,size_t_female,size_t_male] = training_data_feature_extraction()
FrameLen = 400;     % frame size
inc = 160;           % frame increment
%%%kaldi
f_low = 20;
f_high = 7800;
bank_number = 23;

d = dir('Q2_data_set/data/female');
subdirList = fullfile({d.folder}', {d.name}'); 
subdirList(~[d.isdir]) = []; %remove non-directories
speakers_dir = subdirList(3:end);
female.speakers = {d(3:end).name}';
speaker_frames = zeros(10,1);
for i = 1:length(speakers_dir)
    filelist= dir(fullfile(speakers_dir{i}, '*.WAV')); 
    % Loop through files
    frames = 0;
    for j = 1:size(filelist,1)
        [female.speech{i,j},fs] = audioread(fullfile(filelist(j).folder, filelist(j).name)); 
        [female.mfccs{i,j},female.f0{i,j},voiced_frames] = Josh_MFCC_pitch(female.speech{i,j},fs,FrameLen,inc,f_low,f_high,bank_number);
        frames = frames+length(voiced_frames); 
    end
    speaker_frames(i) = frames;
    
end
size_t_female = sum(speaker_frames);

d = dir('Q2_data_set/data/male');
subdirList = fullfile({d.folder}', {d.name}'); 
subdirList(~[d.isdir]) = []; %remove non-directories
speakers_dir = subdirList(3:end);
male.speakers = {d(3:end).name}';

for i = 1:length(speakers_dir)
    filelist= dir(fullfile(speakers_dir{i}, '*.WAV')); 
    % Loop through files
    frames= 0;
    for j = 1:size(filelist,1)
        [male.speech{i,j},fs] = audioread(fullfile(filelist(j).folder, filelist(j).name)); 
        [male.mfccs{i,j},male.f0{i,j},voiced_frames] = Josh_MFCC_pitch(male.speech{i,j},fs,FrameLen,inc,f_low,f_high,bank_number);
        frames = frames+length(voiced_frames);

    end
    speaker_frames(i+5) = frames;
end
size_t_male = sum(speaker_frames)-size_t_female;
end

