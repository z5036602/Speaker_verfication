clear all;clc;
addpath('EM','Joshua_MFCC_matlab','Q1_data_set','Q2_data_set');
[standard_female,standard_male,female,male,speaker_frames,size_t_female,size_t_male] = Q1_feature_extraction();
%creates label
speakers_gender_frame = [repelem({'female'},size_t_female)';repelem({'male'},size_t_male)'];
speakers_gender_utterance = repelem({'female';'male'},50);

%%%total_number_of_frames
size_t = size_t_female+size_t_male;
%%
%frame-level pitch scatter plot
pitch_frame_level = zeros(size_t,1);


% extract pitch from the struct
counter = 1;
for i = 1:size(female.speech,1)
    % Loop through files
    for j = 1:size(female.speech,2)
          pitch_frame_level(counter:counter+length(female.f0{i,j})-1) = female.f0{i,j};
          counter = counter+length(female.f0{i,j});
        
    end
end

% extract pitch from the struct
for i = 1:size(male.speech,1)
    % Loop through files
    for j = 1:size(male.speech,2)
         pitch_frame_level(counter:counter+length(male.f0{i,j})-1) = male.f0{i,j};
         counter = counter+length(male.f0{i,j});
      
        
    end
end


%plots, mean and standard deviation caculation of frame-level pitch
female_mean_frame_level = mean(pitch_frame_level(1:size_t_female));
male_mean_frame_level = mean(pitch_frame_level(size_t_female+1:end));
distance_mean_1 = abs(female_mean_frame_level-male_mean_frame_level);
female_var_1 = std(pitch_frame_level(1:4280));
male_var_1 = std(pitch_frame_level(4281:end));
figure(1);
gscatter(pitch_frame_level,zeros(size(pitch_frame_level)),speakers_gender_frame,'kr','xo')
title('frame level pitch scatter plot')
xlabel('pitch(Hz)');
ylim([-0.04 0.04])
%%
%utterance-level pitch scatter plot
%speakers_gender_utterance = repelem({'female';'male'},50);
pitch_utterance_level = zeros(100,1);
counter = 1;
for i = 1:size(female.speech,1)
    % Loop through files
    for j = 1:size(female.speech,2)
          pitch_utterance_level(counter) = mean(female.f0{i,j});   %%extract mean as the utterance-level
          counter = counter+1;
        
    end
end


for i = 1:size(male.speech,1)
    % Loop through files
    for j = 1:size(male.speech,2)
         pitch_utterance_level(counter) = mean(male.f0{i,j});     %%extract mean as the utterance-level
         counter = counter+1;
      
        
    end
end

%plots, mean and standard deviation caculation of utterance-level pitch

female_mean_utterance_level = mean(pitch_utterance_level(1:50));
male_mean_utterance_level = mean(pitch_utterance_level(51:100));
distance_mean = abs(female_mean_utterance_level-male_mean_utterance_level);
female_var = std(pitch_utterance_level(1:50));
male_var = std(pitch_utterance_level(51:100));
figure(2);
gscatter(pitch_utterance_level,zeros(size(pitch_utterance_level)),speakers_gender_utterance,'br','xo')
title('utterance level pitch scatter plot')
xlabel('pitch(Hz)');
ylim([-0.04 0.04])
%%
%frame-level mfcc pca tsne scatter plot
mfccs = zeros(size_t,13);
counter = 1;
for i = 1:size(female.speech,1)
    % Loop through files
    for j = 1:size(female.speech,2)
          mfccs(counter:counter+size(female.mfccs{i,j},1)-1,:) = female.mfccs{i,j};
          counter = counter+size(female.mfccs{i,j},1);
        
    end
end


for i = 1:size(male.speech,1)
    % Loop through files
    for j = 1:size(male.speech,2)
         mfccs(counter:counter+size(male.mfccs{i,j},1)-1,:) =male.mfccs{i,j};
         counter = counter+size(male.mfccs{i,j},1);
      
        
    end
end

%tsne and pca plots
Y = tsne(mfccs,'Algorithm','barneshut','NumPCAComponents',8);
figure(3);
[coeff] = pca(mfccs); % tsne which is compressing the data using 
reducedDimension = coeff(:,1:2);
reducedData = mfccs * reducedDimension;
gscatter(reducedData(:,1),reducedData(:,2),speakers_gender_frame); 
title('2-d frame level mfcc scatter plot after PCA');
figure(4);
gscatter(Y(:,1),Y(:,2),speakers_gender_frame); 
title('2-d frame level mfcc scatter plot after tsne');
%%
%utterance-level mfcc pca scatter plot
mfcc_utterance = zeros(100,13);
counter = 1;
for i = 1:size(female.speech,1)
    % Loop through files
    for j = 1:size(female.speech,2)
          mfcc_utterance(counter,:) = mean(female.mfccs{i,j});%%extract mean as the utterance-level
          counter = counter+1;
        
    end
end


for i = 1:size(male.speech,1)
    % Loop through files
    for j = 1:size(male.speech,2)
         mfcc_utterance(counter,:) = mean(male.mfccs{i,j});%%extract mean as the utterance-level
         counter = counter+1;
      
        
    end
end

%tsne and pca plots 
figure(5);
[coeff] = pca(mfcc_utterance); % tsne which is compressing the data using 
reducedDimension = coeff(:,1:2);
reducedData = mfcc_utterance * reducedDimension;
gscatter(reducedData(:,1),reducedData(:,2),speakers_gender_utterance);  
title('2-d utterance level mfcc scatter plot after PCA');
%%
%mfcc+pitch 2-d scatter plot after PCA and tsne
mfcc_plus_pitch = [pitch_frame_level, mfccs];


%Normalize the features by subtracting the mean and dividing the standard deviation of each column.
%pitch and MFCC are not on the same scale. This will bias the classifier. 
m = mean(mfcc_plus_pitch);
s = std(mfcc_plus_pitch);
mfcc_plus_pitch = (mfcc_plus_pitch-m)./s;


%tsne and pca plots 
figure(6);
[coeff] = pca(mfcc_plus_pitch); % tsne which is compressing the data using 
reducedDimension = coeff(:,1:2);
reducedData = mfcc_plus_pitch * reducedDimension;
gscatter(reducedData(:,1),reducedData(:,2),speakers_gender_frame);  
title('2-d frame level mfcc+pitch scatter plot after PCA');
Y = tsne(mfcc_plus_pitch,'Algorithm','barneshut','NumPCAComponents',8);

figure(7);
gscatter(Y(:,1),Y(:,2),speakers_gender_frame); 
title('2-d frame level mfcc+pitch scatter plot after tsne');