function [speaker,speaker_frames,size_t] = testing_data_feature_extraction()
FrameLen = 400;     % frame size
inc = 160;           % frame increment
%%%kaldi
f_low = 20;
f_high = 7800;
bank_number = 23;

d = dir('Q2_data_set/data/test_set');
subdirList = fullfile({d.folder}', {d.name}'); 
subdirList(~[d.isdir]) = []; %remove non-directories
speakers_dir = subdirList(3:end);
speaker.speakers = {d(3:end).name}';
%female.speech = cell(5, 10);  %20 files x 20 folders
%c = 0;                       %This is just a counter
speaker_frames = zeros(10,1);
for i = 1:length(speakers_dir)
    filelist= dir(fullfile(speakers_dir{i}, '*.WAV')); 
    % Loop through files
    frames = 0;
    for j = 1:size(filelist,1)
        [speaker.speech{i,j},fs] = audioread(fullfile(filelist(j).folder, filelist(j).name)); 
        [speaker.mfccs{i,j},speaker.f0{i,j},voiced_frames] = Josh_MFCC_pitch(speaker.speech{i,j},fs,FrameLen,inc,f_low,f_high,bank_number);
       
        frames = frames+length(voiced_frames); 
    end
    speaker_frames(i) = frames;
    
end
 size_t = sum(speaker_frames);
end