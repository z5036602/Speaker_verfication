%this function caculates the lilihood of data under different GMM models
% then select the model with highest lilihood as the predication
%output 
%label -- > predicated label
%input 
%GMM_model -->a struct that stores all speakers GMM 
function [label] = GMM_targetsel(testing_utterances,GMM_model)
    scorings = zeros(10,1);
    for speaker_iterator = 1:size(GMM_model,1)
        scorings(speaker_iterator) = GMM_scoring (testing_utterances,GMM_model{speaker_iterator,2});

    end
    [~, idx] = max(scorings);
    label = GMM_model{idx,1};




end