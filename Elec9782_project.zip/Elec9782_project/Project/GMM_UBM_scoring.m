function score = GMM_UBM_scoring (mfcc_data,GMM_model,UBM_model)
     [~,llh_GMM] = latent_pospdf(mfcc_data,GMM_model);
     [~,llh_UBM] = latent_pospdf(mfcc_data,UBM_model);
     score =  llh_GMM - llh_UBM;  



end

