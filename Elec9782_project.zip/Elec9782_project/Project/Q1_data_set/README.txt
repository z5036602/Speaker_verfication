data:
  --female: contains 50 uttereances from 10 female speakers (each speaker has 10 utterances)
  --male: contains 50 uttereances from 10 male speakers (each speaker has 10 utterances)

