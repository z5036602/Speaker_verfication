% this function perform the speaker identification given testing utterance
% and all the speakers' GMM-UBM model
% input:
% testing_utterances --> a struct that stores all the testing utterances 
% speakers_GMM_model --> all speakers GMM model
% speakers_UBM_model --> all speakers UBM model
% output:
% predicted_label --> a struct stores all the predicted label give testing
% data and models
% actual_label --> a struct stores all the ground-truth label

function [predicted_label,actual_label] = GMM_UBM_predication(testing_utterances,speakers_GMM_model,speakers_UBM_model)
    utterance_mfccs = testing_utterances.mfccs;
    speakers = testing_utterances.speakers;
    num_of_speakers = length(speakers);
    num_of_utterances = numel(utterance_mfccs);
    predicted_label = cell(num_of_utterances,1);
    actual_label = cell(num_of_utterances,1);
    counter = 1;
    for speaker_iterator = 1:num_of_speakers
        for utterance_iterator = 1:size(utterance_mfccs,2)
           [prediction] = GMM_UBMtargetsel(utterance_mfccs{speaker_iterator,utterance_iterator},...
               speakers_GMM_model,speakers_UBM_model); 
            predicted_label (counter) = cellstr(prediction);
            actual_label(counter) = cellstr(speakers{speaker_iterator,1});
            counter = counter+1;
        end
    end

end 