%sigmoid function
function output = sigmoid(z)
output = 1./(1+exp(-z));


end