%%%split the train_test data
%shuffle the index, split them by test_train _ratio
%input :
%test_ratio --> portion of data for test data --> data
%output:
%test --> test_data  train -- > train_data
function [test,train] = split_train_test(data,test_ratio)
%     rng = ('default');
    num_of_observations = size(data,1);
    shuffled_indices = K_shuffle([1:num_of_observations]);
    test_set_size = floor(num_of_observations*test_ratio);
    test_indices = shuffled_indices(1:test_set_size);
    train_indices = shuffled_indices(test_set_size:end);
    test = data(test_indices,:);
    train = data(train_indices,:);

end