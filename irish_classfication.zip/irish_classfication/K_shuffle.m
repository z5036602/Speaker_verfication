%%%The function will random shuffle positions of value in a vector
%For, Details see Knuth shuffle
%https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
%input X--> numeric array
%output X--> shuffled numeric array
function [X] = K_shuffle(X)
    n = numel(X);
    for i = 2:n      % Knuth shuffle in forward direction:
        w = ceil(rand * i);   % 1 <= w <= i
        t = X(w);
        X(w) = X(i);
        X(i) = t;
    end
end
