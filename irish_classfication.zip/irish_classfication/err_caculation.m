%Caculate the error by number of unmatch between ground-truth and
%prediction
%input : ture_label --> true_label
%output : predicted_label -->predicted_label
%err --> error in percent 
function err = err_caculation (true_label,predicted_label)
    counter = 0;
    for k = 1: length(true_label)
        if true_label(k) ~= predicted_label (k)
            counter = counter + 1;
        end 
        
    end

    err = counter / length (true_label)*100;

end 