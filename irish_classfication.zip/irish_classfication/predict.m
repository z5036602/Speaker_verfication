%%%predict the label,given the model paramters theta
%input:
%   test--> test_data;
%output:
%   result-->the output here is the numer corresponding 
% to the postion of label in label array.
function [result] = predict(theta,test)
    test = str2double(test(:,2:end));
    test_data = (test - mean(test))./std(test);
    test_data = [ones(size(test,1),1),test_data];

    h = sigmoid(test_data*theta);
    [~,col] = max(h,[],2);
    result = col;
    
    
end