%marking the data_label setted by user as 1 
%all other data_label are marked as zeros
%input :
%data --> data str --> data_label that user want
%marked data label
function [data] = split_data_by_binary_category(data,str)
    false_index = find(data(:,1) ~=str);
    true_index = find(data(:,1) ==str);
    data(true_index,1) = 1; 
    data(false_index,1) = 0; 
end