%(critical function) 
%learning the parameter for logistic regression
%input : 
%data-->training_data str-->the category we want for logistic...
%regression so the data belongs to the category labeled as 1, data outside
%of the category labeled as 0(one vs all); alpha-->
%learning_rate;iter-->number of iteration for gradient decent
%output :
%theta --> trained_output J-->cost function
function [theta, J] = model_creation(data,str,alpha,iter)
    [data] = split_data_by_binary_category(data,str);
    y = str2double(data(:,1));
    x_raw = str2double(data(:,2:end));
    x = (x_raw - mean(x_raw))./std(x_raw);
    
    x = [ones(size(x,1),1),x];
    theta = zeros(size(x,2),1);
    m = size(x,1);
    J = 0;
    counter = 0;
    for k = 1:iter 
        h = sigmoid(x*theta);
        J = (-1/m)*sum(y.*log(h)+(1-y).*log(1-h));
         counter = counter +1;    
        theta = theta-(alpha/m)*x'*(h-y);
    end

end