clear;clc;
load fisheriris.mat	
rng = ('default');
%%%split data to test data and train data
test_ratio = 0.3;

data_with_label = [string(species),meas];
categories = unique(string(species));
[test,train] = split_train_test(data_with_label,test_ratio);

%%%train parameter for each category(one vs all) and stored in a matrix
theta = zeros(length(categories),size(meas,2)+1)';
J = zeros(3,1);

[theta(:,1),J(1)] = model_creation(train,categories(1),0.1,10000);    %Question:    
[theta(:,2),J(2)] = model_creation(train,categories(2),0.2,10000);    %quicker learning rate needed    
[theta(:,3),J(3)] = model_creation(train,categories(3),0.2,10000);     %why they did not converge to same point?   

%%%prediction
result = predict(theta,test);
predicted_label = categories(result);
true_label = test(:,1);

%%%error and confusion matrix
error = err_caculation (true_label,predicted_label);
disp(['Err is : ', num2str(error) , '%']);
figure
cm = confusionchart(true_label,predicted_label);



